/**
 * Chatbot para Campanha Política
 * Open Source - MIT License
 * 
 * Este chatbot responde apenas sobre:
 * - O candidato Tita Nio
 * - O partido PAC
 * - As propostas de campanha
 */

const ChatBot = {
    // Base de conhecimento do candidato
    knowledge: {
        candidato: {
            nome: "Tita Nio dos Santos",
            idade: "47 anos",
            profissao: "Economista e Professor Universitário",
            partido: "PAC - Partido Aliança Cidadã",
            numero: "47",
            slogan: "Juntos por um Brasil que cuida",
            nascimento: "Belo Horizonte, MG",
            formacao: ["Economia (UFMG)", "Mestrado em Políticas Públicas (USP)", "Doutorado em Desenvolvimento Sustentável (UnB)"],
            familia: "Casado, pai de 2 filhos",
            trajetoria: [
                "Professor universitário na PUC Minas (1998-2005)",
                "Secretaria de Desenvolvimento Social de MG (2005-2012)",
                "Vereador de Belo Horizonte (2012-2018) - mais votado do partido",
                "Deputado Estadual (2018-2024)"
            ],
            conquistas: [
                "Programa 'Escola Integral para Todos'",
                "Lei de incentivo a startups de impacto social",
                "Portal da Cidadania BH",
                "Lei Estadual de Energia Renovável",
                "Programa 'Primeiro Emprego Tech' - 12 mil jovens capacitados"
            ],
            diferenciais: [
                "Ficha limpa - zero processos judiciais",
                "100% de presença na Câmara",
                "Mais de 50 mil famílias beneficiadas",
                "25 anos de vida pública"
            ]
        },
        partido: {
            nome: "Partido Aliança Cidadã",
            sigla: "PAC",
            numero: "47",
            fundacao: "2015",
            posicionamento: "Centro-esquerda progressista",
            slogan: "Juntos por um Brasil que cuida",
            valores: [
                "Justiça Social",
                "Sustentabilidade", 
                "Democracia Participativa",
                "Inovação com Propósito",
                "Ética e Transparência",
                "Inclusão"
            ],
            diferenciais: [
                "Ficha limpa obrigatória para todos os candidatos",
                "Mandato coletivo com conselhos populares",
                "Transparência total das contas",
                "50% das vagas para jovens e mulheres",
                "Financiamento 100% público e crowdfunding"
            ]
        },
        propostas: {
            educacao: {
                titulo: "Educação para Todos",
                meta: "Brasil entre os 30 melhores em educação até 2030",
                itens: [
                    "Escola em tempo integral para 100% da rede pública",
                    "Piso de R$ 8.500 para professores",
                    "Zero analfabetismo",
                    "500 mil novas vagas em universidades federais",
                    "Um tablet por aluno, programação no currículo",
                    "Creche para todos de 0-3 anos"
                ]
            },
            saude: {
                titulo: "Saúde de Verdade",
                meta: "SUS referência mundial",
                itens: [
                    "UBS 24 horas",
                    "Um médico para cada 1.000 habitantes",
                    "Fila zero - exames e cirurgias em até 30 dias",
                    "CAPS em todos os municípios",
                    "Farmácia Popular ampliada",
                    "Telemedicina para áreas remotas"
                ]
            },
            emprego: {
                titulo: "Emprego e Renda",
                meta: "Menor desemprego da história",
                itens: [
                    "Programa Primeiro Emprego",
                    "MEI sem burocracia, crédito acessível",
                    "2 milhões de empregos em energia renovável",
                    "Salário mínimo com reajuste real",
                    "Cursos técnicos gratuitos",
                    "Apoio a cooperativas e agricultura familiar"
                ]
            },
            meioambiente: {
                titulo: "Meio Ambiente",
                meta: "Brasil carbono neutro até 2040",
                itens: [
                    "Desmatamento zero",
                    "100% energia renovável até 2035",
                    "Ônibus elétricos, ciclovias, metrô",
                    "Coleta seletiva em 100% dos municípios",
                    "Saneamento básico universal",
                    "Fundo de preservação da Amazônia"
                ]
            },
            seguranca: {
                titulo: "Segurança Cidadã",
                meta: "Reduzir violência em 50%",
                itens: [
                    "Polícia comunitária",
                    "Câmeras inteligentes, integração de dados",
                    "Socioeducação - recuperar, não apenas punir",
                    "Combate às milícias",
                    "Política restritiva de armamento",
                    "Fim da violência policial"
                ]
            },
            moradia: {
                titulo: "Moradia Digna",
                meta: "Déficit habitacional zero",
                itens: [
                    "2 milhões de moradias em 4 anos",
                    "Aluguel social",
                    "Urbanização de favelas",
                    "Crédito acessível com juros baixos"
                ]
            },
            governo: {
                titulo: "Governo Digital e Transparente",
                meta: "Estado 100% digital e transparente",
                itens: [
                    "Serviços públicos pelo app",
                    "Dados abertos em tempo real",
                    "Orçamento participativo",
                    "IA para detectar fraudes"
                ]
            },
            cultura: {
                titulo: "Cultura e Esporte",
                meta: "Cultura e esporte como direito",
                itens: [
                    "Vale Cultura R$ 100/mês",
                    "Praças da Juventude em cada bairro",
                    "10 mil novos Pontos de Cultura",
                    "Bolsa Atleta expandida"
                ]
            }
        }
    },

    // Padrões de perguntas e respostas
    patterns: [
        // Saudações
        {
            patterns: ['olá', 'oi', 'opa', 'eae', 'e aí', 'bom dia', 'boa tarde', 'boa noite', 'hey', 'hi'],
            response: () => `Olá! 👋 Sou o assistente virtual da campanha do Tita Nio 47. Posso te contar sobre o candidato, suas propostas ou sobre o PAC. O que você gostaria de saber?`
        },
        // Quem é o candidato
        {
            patterns: ['quem é', 'quem e', 'quem é tita', 'quem é o candidato', 'sobre o candidato', 'me fale sobre', 'conte sobre'],
            response: () => {
                const c = ChatBot.knowledge.candidato;
                return `**Tita Nio dos Santos** é economista, professor universitário e político com 25 anos de vida pública. 

🎓 Formado em Economia pela UFMG com bolsa integral, tem mestrado em Políticas Públicas e doutorado em Desenvolvimento Sustentável.

📋 Foi vereador mais votado de BH e deputado estadual. Criou programas importantes como a "Escola Integral para Todos" e a Lei de Energia Renovável.

✅ Ficha 100% limpa, nunca faltou uma sessão, e já beneficiou mais de 50 mil famílias com seus projetos.

${c.familia}, nascido em ${c.nascimento}. Seu lema: "${c.slogan}"`;
            }
        },
        // História do candidato
        {
            patterns: ['história', 'trajetória', 'biografia', 'vida', 'carreira', 'origem'],
            response: () => {
                const c = ChatBot.knowledge.candidato;
                return `**A história de Tita Nio** é de superação:

👶 Nasceu em família humilde no bairro Lagoinha, em BH. Filho de professora e metalúrgico.

📚 Estudou em escola pública a vida toda. Aos 17, conquistou bolsa integral na UFMG.

👨‍🏫 Como professor, criou projetos de extensão que ajudaram comunidades a formar cooperativas de crédito.

🏛️ Na política:
• 2005-2012: Secretaria de Desenvolvimento Social
• 2012-2018: Vereador de BH (mais votado do partido)
• 2018-2024: Deputado Estadual

💪 Sempre lutou pela educação, transparência e desenvolvimento sustentável!`;
            }
        },
        // Propostas gerais
        {
            patterns: ['proposta', 'plano', 'programa', 'vai fazer', 'quer fazer', 'pretende'],
            response: () => {
                return `**As 8 bandeiras da campanha de Tita Nio:**

📚 **Educação** - Escola integral 100%, piso de R$8.500 para professores
🏥 **Saúde** - UBS 24h, fila zero, CAPS em todos os municípios
💼 **Emprego** - 2 milhões de empregos verdes, crédito fácil para MEI
🌱 **Meio Ambiente** - Brasil carbono neutro até 2040
🛡️ **Segurança** - Polícia comunitária, reduzir violência em 50%
🏠 **Moradia** - 2 milhões de casas, déficit zero
📱 **Governo Digital** - Serviços 100% online, transparência total
🎭 **Cultura** - Vale Cultura R$100/mês, Praças da Juventude

Quer saber mais sobre alguma área específica?`;
            }
        },
        // Educação
        {
            patterns: ['educação', 'educacao', 'escola', 'professor', 'ensino', 'universidade'],
            response: () => {
                const p = ChatBot.knowledge.propostas.educacao;
                return `📚 **${p.titulo}**
Meta: ${p.meta}

${p.itens.map(i => `✓ ${i}`).join('\n')}

A educação é a prioridade nº 1 do governo Tita Nio!`;
            }
        },
        // Saúde
        {
            patterns: ['saúde', 'saude', 'hospital', 'médico', 'medico', 'sus', 'ubs', 'posto'],
            response: () => {
                const p = ChatBot.knowledge.propostas.saude;
                return `🏥 **${p.titulo}**
Meta: ${p.meta}

${p.itens.map(i => `✓ ${i}`).join('\n')}

Investimento: 8% do PIB para saúde pública!`;
            }
        },
        // Emprego
        {
            patterns: ['emprego', 'trabalho', 'desemprego', 'renda', 'salário', 'salario', 'mei'],
            response: () => {
                const p = ChatBot.knowledge.propostas.emprego;
                return `💼 **${p.titulo}**
Meta: ${p.meta}

${p.itens.map(i => `✓ ${i}`).join('\n')}

R$ 50 bilhões para financiar pequenas e médias empresas!`;
            }
        },
        // Meio ambiente
        {
            patterns: ['meio ambiente', 'ambiente', 'sustentável', 'sustentavel', 'verde', 'clima', 'desmatamento', 'energia'],
            response: () => {
                const p = ChatBot.knowledge.propostas.meioambiente;
                return `🌱 **${p.titulo}**
Meta: ${p.meta}

${p.itens.map(i => `✓ ${i}`).join('\n')}

3% do PIB para a transição energética!`;
            }
        },
        // Segurança
        {
            patterns: ['segurança', 'seguranca', 'violência', 'violencia', 'polícia', 'policia', 'crime'],
            response: () => {
                const p = ChatBot.knowledge.propostas.seguranca;
                return `🛡️ **${p.titulo}**
Meta: ${p.meta}

${p.itens.map(i => `✓ ${i}`).join('\n')}

Filosofia: Inteligência > Truculência`;
            }
        },
        // Moradia
        {
            patterns: ['moradia', 'casa', 'habitação', 'habitacao', 'aluguel', 'favela'],
            response: () => {
                const p = ChatBot.knowledge.propostas.moradia;
                return `🏠 **${p.titulo}**
Meta: ${p.meta}

${p.itens.map(i => `✓ ${i}`).join('\n')}`;
            }
        },
        // Partido
        {
            patterns: ['partido', 'pac', 'aliança cidadã', 'alianca cidada', 'qual partido'],
            response: () => {
                const p = ChatBot.knowledge.partido;
                return `**${p.nome} (${p.sigla}) - ${p.numero}**

📅 Fundado em ${p.fundacao}
🎯 Posicionamento: ${p.posicionamento}
💬 Slogan: "${p.slogan}"

**Valores:**
${p.valores.map(v => `• ${v}`).join('\n')}

**Diferenciais:**
${p.diferenciais.map(d => `✓ ${d}`).join('\n')}`;
            }
        },
        // Número
        {
            patterns: ['número', 'numero', 'voto', 'votar', 'qual o número'],
            response: () => `O número do Tita Nio é **47**! 🗳️\n\n**TITA NIO - 47**\nPartido Aliança Cidadã (PAC)\n\nJuntos por um Brasil que cuida! 💚🧡`
        },
        // Conquistas
        {
            patterns: ['conquista', 'realizou', 'fez', 'feito', 'resultado'],
            response: () => {
                const c = ChatBot.knowledge.candidato;
                return `**Principais conquistas de Tita Nio:**

${c.conquistas.map(x => `✅ ${x}`).join('\n')}

**Diferenciais:**
${c.diferenciais.map(x => `⭐ ${x}`).join('\n')}`;
            }
        },
        // Ficha limpa
        {
            patterns: ['ficha', 'processo', 'corrupção', 'corrupcao', 'limpo', 'honesto'],
            response: () => `Tita Nio tem **ficha 100% limpa**! ✅

• Zero processos judiciais
• 100% de presença nas sessões
• Nunca envolvido em escândalos
• Patrimônio declarado e compatível

A transparência é um dos pilares do PAC. Tolerância zero com corrupção!`
        },
        // Despedida
        {
            patterns: ['tchau', 'até', 'obrigado', 'obrigada', 'valeu', 'falou', 'bye'],
            response: () => `Foi um prazer ajudar! 😊\n\nLembre-se: **TITA NIO - 47**\nJuntos por um Brasil que cuida! 💚🧡\n\nQualquer dúvida, é só voltar aqui!`
        },
        // Ajuda
        {
            patterns: ['ajuda', 'help', 'como funciona', 'o que você faz'],
            response: () => `Sou o assistente virtual da campanha! 🤖\n\nPosso te ajudar com:\n• Informações sobre **Tita Nio**\n• **Propostas** de governo\n• O partido **PAC**\n• **Conquistas** do candidato\n• Como **votar** (número 47)\n\nÉ só perguntar!`
        }
    ],

    // Resposta padrão quando não entende
    defaultResponse: () => {
        const suggestions = [
            "Quem é Tita Nio?",
            "Quais são as propostas?",
            "Me fale sobre o PAC",
            "Qual o número para votar?"
        ];
        return `Desculpe, não entendi muito bem. 🤔\n\nPosso te ajudar com:\n${suggestions.map(s => `• "${s}"`).join('\n')}\n\nTente uma dessas perguntas!`;
    },

    // Encontrar melhor resposta
    findResponse(message) {
        const normalized = message.toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .trim();

        for (const pattern of this.patterns) {
            for (const p of pattern.patterns) {
                if (normalized.includes(p)) {
                    return pattern.response();
                }
            }
        }

        return this.defaultResponse();
    },

    // Inicializar chatbot
    init() {
        const toggle = document.querySelector('.chatbot-toggle');
        const window = document.querySelector('.chatbot-window');
        const close = document.querySelector('.chatbot-close');
        const input = document.getElementById('chat-input');
        const send = document.getElementById('chat-send');
        const messages = document.getElementById('chat-messages');

        // Toggle window
        toggle?.addEventListener('click', () => {
            window.classList.toggle('active');
            if (window.classList.contains('active')) {
                input?.focus();
            }
        });

        // Close window
        close?.addEventListener('click', () => {
            window.classList.remove('active');
        });

        // Send message
        const sendMessage = () => {
            const text = input?.value.trim();
            if (!text) return;

            // Add user message
            this.addMessage(text, 'user');
            input.value = '';

            // Get bot response
            setTimeout(() => {
                const response = this.findResponse(text);
                this.addMessage(response, 'bot');
            }, 500);
        };

        send?.addEventListener('click', sendMessage);
        input?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') sendMessage();
        });

        // Quick replies
        document.querySelectorAll('.quick-reply').forEach(btn => {
            btn.addEventListener('click', () => {
                const msg = btn.dataset.message;
                input.value = msg;
                sendMessage();
            });
        });
    },

    // Add message to chat
    addMessage(text, sender) {
        const messages = document.getElementById('chat-messages');
        const quickReplies = messages?.querySelector('.quick-replies');
        
        const div = document.createElement('div');
        div.className = `message ${sender}`;
        div.innerHTML = `<p>${text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>')}</p>`;
        
        if (quickReplies) {
            messages.insertBefore(div, quickReplies);
        } else {
            messages?.appendChild(div);
        }
        
        messages.scrollTop = messages.scrollHeight;
    }
};

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', () => {
    ChatBot.init();
});
