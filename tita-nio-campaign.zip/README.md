# Tita Nio 47 - Plataforma de Campanha Política

![License](https://img.shields.io/badge/license-MIT-green)
![Status](https://img.shields.io/badge/status-em%20desenvolvimento-yellow)

**Sistema completo para campanhas políticas** com site responsivo, chatbot integrado e documentação completa.

> ⚠️ **AVISO**: Este é um projeto de demonstração com um candidato **FICTÍCIO**. Criado para fins educacionais e comerciais.

## 🎯 Sobre o Projeto

Plataforma white-label para campanhas políticas contendo:

- 🌐 **Site responsivo** - Landing page moderna e profissional
- 🤖 **Chatbot inteligente** - Responde sobre o candidato, propostas e partido
- 📱 **Mobile-first** - Funciona perfeitamente em qualquer dispositivo
- 📄 **Documentação completa** - Candidato, partido e programa de governo

## 🚀 Demonstração

O candidato de demonstração é **Tita Nio**, do **Partido Aliança Cidadã (PAC) - 47**.

### Características do candidato fictício:
- Centro-esquerda progressista
- Economista e professor universitário
- 25 anos de vida pública
- Ficha limpa

## 📁 Estrutura do Projeto

```
tita-nio-campaign/
├── docs/                    # Documentação do candidato
│   ├── CANDIDATO.md         # Biografia e histórico
│   ├── PARTIDO.md           # Informações do partido
│   └── PROGRAMA.md          # Propostas de governo
├── site/                    # Site da campanha
│   ├── index.html           # Página principal
│   ├── css/
│   │   └── style.css        # Estilos
│   ├── js/
│   │   ├── main.js          # Scripts principais
│   │   └── chatbot.js       # Lógica do chatbot
│   └── assets/              # Imagens e recursos
├── LICENSE                  # Licença MIT
└── README.md                # Este arquivo
```

## 🛠️ Tecnologias

- **HTML5** - Estrutura semântica
- **CSS3** - Estilos modernos com variáveis CSS
- **JavaScript** - Vanilla JS (sem dependências)
- **Google Fonts** - Tipografia (Poppins)

## 🎨 Personalização

### Cores
Edite as variáveis CSS em `site/css/style.css`:

```css
:root {
    --color-primary: #20B2AA;    /* Verde água */
    --color-secondary: #FF6B35;  /* Laranja */
    --color-dark: #1a1a2e;
}
```

### Chatbot
A base de conhecimento está em `site/js/chatbot.js`. Edite o objeto `knowledge` para personalizar as respostas.

### Conteúdo
Edite os arquivos em `docs/` para alterar informações do candidato, partido e propostas.

## 📦 Instalação

1. Clone o repositório:
```bash
git clone https://github.com/contact703/tita-nio-campaign.git
```

2. Abra `site/index.html` no navegador ou sirva com qualquer servidor estático:
```bash
npx serve site/
```

## 🌐 Deploy

O site é 100% estático e pode ser hospedado em:

- **GitHub Pages** (gratuito)
- **Netlify** (gratuito)
- **Vercel** (gratuito)
- Qualquer servidor web

## 📱 App Android (Em breve)

Versão mobile nativa usando:
- React Native ou
- WebView wrapper

## 🤝 Contribuindo

Contribuições são bem-vindas! Abra uma issue ou envie um PR.

## 📄 Licença

Este projeto está sob a licença **MIT**. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

**Livre para uso comercial** ✅

## 👤 Autor

Desenvolvido por [Titanio Films](https://github.com/contact703)

---

**Nota**: Este é um projeto de demonstração. Para uso em campanhas reais, certifique-se de seguir a legislação eleitoral do seu país.
