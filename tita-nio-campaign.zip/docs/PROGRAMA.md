# Programa de Governo - Tita Nio 47

## "Juntos por um Brasil que cuida"

---

## 1. EDUCAÇÃO PARA TODOS 📚

### Meta: Brasil entre os 30 melhores em educação até 2030

**Propostas:**
- **Escola em Tempo Integral** - Expandir para 100% da rede pública em 4 anos
- **Professor Valorizado** - Piso de R$ 8.500 + plano de carreira
- **Zero Analfabetismo** - Programa intensivo para jovens e adultos
- **Universidade Aberta** - 500 mil novas vagas em federais
- **Tech nas Escolas** - Um tablet por aluno, programação no currículo
- **Creche para Todos** - Vagas garantidas de 0-3 anos

**Investimento:** Educação como prioridade nº 1 do orçamento

---

## 2. SAÚDE DE VERDADE 🏥

### Meta: SUS referência mundial

**Propostas:**
- **UBS 24h** - Postos de saúde funcionando dia e noite
- **Médico na Família** - Um médico para cada 1.000 habitantes
- **Fila Zero** - Exames e cirurgias em até 30 dias
- **Saúde Mental** - CAPS em todos os municípios
- **Farmácia Popular** - Medicamentos gratuitos ampliados
- **Telemedicina** - Consultas online para áreas remotas

**Investimento:** 8% do PIB para saúde pública

---

## 3. EMPREGO E RENDA 💼

### Meta: Menor desemprego da história

**Propostas:**
- **Primeiro Emprego** - Incentivo fiscal para contratar jovens
- **Empreenda Fácil** - MEI sem burocracia, crédito acessível
- **Indústria Verde** - 2 milhões de empregos em energia renovável
- **Salário Mínimo Digno** - Reajuste real acima da inflação
- **Qualifica Brasil** - Cursos técnicos gratuitos em parceria com empresas
- **Economia Solidária** - Apoio a cooperativas e agricultura familiar

**Investimento:** Banco de Desenvolvimento com R$ 50 bi para PMEs

---

## 4. MEIO AMBIENTE 🌱

### Meta: Brasil carbono neutro até 2040

**Propostas:**
- **Desmatamento Zero** - Fiscalização com satélite e punição severa
- **Energia Limpa** - 100% renovável até 2035
- **Mobilidade Verde** - Ônibus elétricos, ciclovias, metrô
- **Reciclagem Total** - Coleta seletiva em 100% dos municípios
- **Água para Todos** - Saneamento básico universal
- **Amazônia Protegida** - Fundo internacional de preservação

**Investimento:** 3% do PIB para transição energética

---

## 5. SEGURANÇA CIDADÃ 🛡️

### Meta: Reduzir violência em 50%

**Propostas:**
- **Polícia Comunitária** - Policial de referência em cada bairro
- **Tecnologia contra o Crime** - Câmeras inteligentes, integração de dados
- **Socioeducação** - Recuperar, não apenas punir
- **Combate às Milícias** - Tolerância zero com crime organizado
- **Armas sob Controle** - Política restritiva de armamento
- **Direitos Humanos** - Fim da violência policial

**Investimento:** Inteligência > Truculência

---

## 6. MORADIA DIGNA 🏠

### Meta: Déficit habitacional zero

**Propostas:**
- **Minha Casa Popular** - 2 milhões de moradias em 4 anos
- **Aluguel Social** - Auxílio para famílias em vulnerabilidade
- **Urbaniza Favela** - Saneamento e regularização fundiária
- **Crédito Acessível** - Financiamento a juros baixos
- **Prédios Públicos Ociosos** - Conversão em moradia popular

---

## 7. GOVERNO DIGITAL E TRANSPARENTE 📱

### Meta: Estado 100% digital e transparente

**Propostas:**
- **Tudo pelo App** - Serviços públicos na palma da mão
- **Dados Abertos** - Todas as contas em tempo real
- **Orçamento Participativo** - Povo decide parte do orçamento
- **Fim do Fura-fila** - Sistema único, sem privilégios
- **Combate à Corrupção** - IA para detectar fraudes

---

## 8. CULTURA E ESPORTE 🎭⚽

### Meta: Cultura e esporte como direito

**Propostas:**
- **Vale Cultura** - R$ 100/mês para trabalhadores
- **Praças da Juventude** - Equipamentos esportivos em cada bairro
- **Pontos de Cultura** - 10 mil novos espaços culturais
- **Bolsa Atleta** - Expandir para esportes amadores

---

## COMPROMISSOS DE CAMPANHA

✅ Não aumentar impostos para a classe média
✅ Manter responsabilidade fiscal
✅ Respeitar a Constituição e as instituições
✅ Governar para todos, sem distinção
✅ Prestar contas mensalmente à população

---

## FINANCIAMENTO

- Reforma tributária progressiva (rico paga mais)
- Combate à sonegação (R$ 600 bi/ano perdidos)
- Eficiência do gasto público
- Parcerias público-privadas transparentes
- Fundos internacionais de clima

---

**"Não prometo milagres. Prometo trabalho, honestidade e um Brasil mais justo."**

*Tita Nio - 47*
