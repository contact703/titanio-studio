# Tita Nio - Candidato

## Dados Pessoais
- **Nome completo:** Tita Nio dos Santos
- **Idade:** 47 anos
- **Natural de:** Belo Horizonte, MG
- **Estado civil:** Casado, 2 filhos
- **Profissão:** Economista e Professor Universitário
- **Formação:** 
  - Economia (UFMG)
  - Mestrado em Políticas Públicas (USP)
  - Doutorado em Desenvolvimento Sustentável (UnB)

## Biografia

Tita Nio nasceu em uma família humilde no bairro Lagoinha, em Belo Horizonte. Filho de uma professora primária e um metalúrgico, aprendeu desde cedo o valor da educação e do trabalho digno.

Estudou em escola pública durante toda a infância e adolescência. Aos 17 anos, conquistou uma bolsa integral na UFMG, onde se formou em Economia com honras. Foi durante a universidade que descobriu sua paixão por políticas públicas e justiça social.

### Trajetória Profissional

**1998-2005 - Professor Universitário**
Lecionou Economia na PUC Minas, onde desenvolveu projetos de extensão em comunidades carentes, ajudando a criar cooperativas de crédito popular.

**2005-2012 - Secretaria de Desenvolvimento Social**
Foi convidado para integrar a equipe técnica da Secretaria de Desenvolvimento Social de MG, onde coordenou programas de transferência de renda que beneficiaram mais de 50 mil famílias.

**2012-2018 - Vereador de Belo Horizonte**
Eleito com mais de 45 mil votos, foi o vereador mais votado da história do partido. Principais conquistas:
- Criou o programa "Escola Integral para Todos"
- Aprovou lei de incentivo a startups de impacto social
- Lutou pela transparência: criou o Portal da Cidadania BH
- 100% de presença nas sessões da Câmara

**2018-2024 - Deputado Estadual**
Reeleito com votação recorde. Realizações:
- Autor da Lei Estadual de Energia Renovável
- Criou o programa "Primeiro Emprego Tech" - 12 mil jovens capacitados
- Presidente da Comissão de Educação
- Relator do Plano Estadual de Combate à Pobreza

## Bandeiras Históricas

1. **Educação de qualidade** - Sempre defendeu investimento em educação pública
2. **Desenvolvimento sustentável** - Economia verde e empregos do futuro
3. **Transparência** - Governo aberto e combate à corrupção
4. **Inclusão digital** - Tecnologia para todos
5. **Saúde pública** - SUS forte e eficiente

## Características Pessoais

- **Estilo:** Comunicativo, didático, próximo do povo
- **Pontos fortes:** Honestidade, preparo técnico, histórico limpo
- **Hobby:** Ciclista urbano, toca violão
- **Frase marcante:** "Política se faz com as pessoas, não para as pessoas"

## Redes Sociais (fictícias)
- @titanio
- /titaniooficial
- titanio.com.br
