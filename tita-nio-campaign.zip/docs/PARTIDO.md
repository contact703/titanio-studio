# Partido Aliança Cidadã (PAC)

## Identidade

- **Nome:** Partido Aliança Cidadã
- **Sigla:** PAC
- **Número:** 47
- **Fundação:** 2015
- **Slogan:** "Juntos por um Brasil que cuida"
- **Cores oficiais:** 
  - Verde água (#20B2AA) - representa sustentabilidade
  - Laranja (#FF6B35) - representa energia e transformação
  - Branco (#FFFFFF) - representa transparência

## Posicionamento Político

**Centro-esquerda progressista**

O PAC acredita em:
- Economia de mercado com forte regulação e proteção social
- Estado presente nos serviços essenciais (saúde, educação, segurança)
- Desenvolvimento sustentável como prioridade
- Direitos humanos e inclusão de minorias
- Democracia participativa e transparência
- Combate às desigualdades sociais

## Princípios Fundamentais

### 1. Justiça Social
Redução das desigualdades através de políticas públicas eficientes e redistributivas.

### 2. Sustentabilidade
Desenvolvimento econômico em harmonia com o meio ambiente, priorizando energias renováveis e economia circular.

### 3. Democracia Participativa
Governar com o povo, não apenas para o povo. Conselhos populares, orçamento participativo, transparência total.

### 4. Inovação com Propósito
Tecnologia a serviço da sociedade, inclusão digital, governo digital eficiente.

### 5. Ética e Transparência
Tolerância zero com corrupção, prestação de contas permanente, políticos ficha limpa.

## História do Partido

O PAC nasceu em 2015 da união de movimentos sociais, lideranças comunitárias, acadêmicos e empreendedores sociais que não se sentiam representados pelos partidos tradicionais.

Fundado por um grupo de 50 cidadãos em Belo Horizonte, o partido cresceu rapidamente por sua proposta de renovação política com responsabilidade.

**Marcos importantes:**
- 2015: Fundação em BH com 50 membros
- 2016: Elege 12 vereadores em MG
- 2018: Elege 3 deputados estaduais e 1 federal
- 2020: 45 vereadores eleitos no Brasil
- 2022: 8 deputados federais, 15 estaduais
- 2024: Tita Nio lança candidatura ao executivo

## Lideranças

- **Presidente Nacional:** Maria Clara Souza (educadora)
- **Vice-presidente:** João Pedro Lima (ambientalista)
- **Secretário-geral:** Ana Beatriz Costa (advogada)

## Diferenciais

1. **Ficha limpa obrigatória** - Nenhum candidato com pendências judiciais
2. **Mandato coletivo** - Conselhos populares assessoram todos os mandatos
3. **Transparência total** - Todas as contas públicas em tempo real
4. **Renovação** - 50% das vagas para jovens e mulheres
5. **Sem empresários de campanha** - Financiamento 100% público e crowdfunding
